<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Customer;
use App\Models\Partner;
use App\Models\User;
use App\Models\Product;
use App\Models\ProductStock;
use App\Models\ProductPrice;
use App\Models\CustomQuotation;
use App\Models\SalesInvoiceMaster;
use App\Models\SalesInvoiceItem;
use App\Models\SalesOrderItem;
use App\Models\SalesOrderMaster;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Yajra\DataTables\DataTables;

class SalesInvoiceController extends Controller
{

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function index(Request $request)
    {

        if ($request->ajax()) {
            if (Auth::user()->hasRole('Admin')) {
                $data = SalesOrderMaster::select('sales_order_masters.*')->with(array('customer', 'referral1', 'referral2', 'referral3'));
            } else {
                $data = SalesOrderMaster::select('sales_order_masters.*')->with(array('customer', 'referral1', 'referral2', 'referral3'))
                    ->where(function ($query) {
                        $query->Where('createdBy', Auth::user()->id);
                    });
            }
            if (!empty($request->from_date)) {
                //echo "here";
                $data->where('doc_date', '>=', $request->from_date);
            }
            if (!empty($request->to_date)) {
                //echo "here";
                $data->where('doc_date', '<=', $request->to_date);
            }
            if (!empty($request->customer)) {
                //echo "here";
                $data->where('sales_order_masters.cid', $request->customer);
            }
            if (!empty($request->user)) {
                //echo "here";
                $data->where('sales_order_masters.createdBy', $request->user);
            }
            if (!empty($request->status)) {
                if ($request->status == "All") {
                    $data->where('sales_order_masters.status', '!=', 'Cancel');
                } else {
                    $data->where('sales_order_masters.status', $request->status);
                }
            } else {
                $data->where('sales_order_masters.status', 'Open');
            }
                $data->where('sales_order_masters.branch', session('branch_code'));

                $data->orderBy('cid', 'desc');

                // dd($data);
                return Datatables::of($data)
                ->addColumn('DocNo', function ($row) {
                    if ($row->doc_num)
                        return $row->doc_num;
                    else
                        return null;

                })
                ->addColumn('action', function ($row) {
                    $url = url('admin/sales-order/' . $row->id);
                    $url_edit = url('admin/sales-order/' . $row->id . '/edit');
                    $btn = '<a href=' . $url . ' class="btn btn-primary"><i class="mdi mdi-eye"></i>View</a>';
                        /*
                        <a href="javascript:void(0);" onclick="open_closemodal('.$row->id.')" class="btn btn-danger close-icon"><i class="mdi mdi-delete"></i>Close</a>
                        */
                    // if ((($row->status == 'Approve' || $row->status == 'Open') && (Auth::user()->hasRole('Admin') || $row->manager1 == Auth::user()->id || $row->manager2 == Auth::user()->id)) || $row->status == 'Send for Approval') {
                    //     $btn .= '&nbsp;<a href=' . $url_edit . ' class="btn btn-info"><i class="mdi mdi-square-edit-outline"></i>Edit</a>&nbsp;';
                    // }

                    // if ($row->status == 'Approve' && (Auth::user()->hasRole('Admin') || $row->manager1 == Auth::user()->id || $row->manager2 == Auth::user()->id)) {
                    //     $btn .= '&nbsp;<a href="javascript:void(0);" onclick="open_approvemodal(' . $row->id . ')" class="btn btn-primary"><i class="mdi mdi-plus-circle me-1"></i>Confirm</a>';
                    // }

                    // if (($row->status == 'Open' || $row->status == 'Send for Approval') && (Auth::user()->hasRole('Admin') || $row->manager1 == Auth::user()->id || $row->manager2 == Auth::user()->id)) {
                    //     $btn .= '&nbsp;<a href="javascript:void(0);" onclick="open_closemodal(' . $row->id . ')" class="btn btn-danger close-icon"><i class="mdi mdi-delete"></i>Close</a>';
                    // }
                    return $btn;
                })
                ->addColumn('customer', function ($row) {
                    if ($row->customer) {
                        $n = $row->customer->name;
                        return substr($n, 0, 27);
                    } else
                        return null;
                })
                ->addColumn('doc_date', function ($row) {
                    if ($row->cid)
                        return $row->doc_date;
                    else
                        return null;

                })
                ->addColumn('delivery_date', function ($row) {
                    if ($row->cid)
                        return $row->delivery_date;
                    else
                        return null;
                })
                ->addColumn('sales_emp_id', function ($row) {
                    if ($row->referral3)
                    return $row->referral3->name;
                    else
                    return null;

                })
                ->addColumn('PriceList', function ($row) {
                    if ($row->total)
                        return $row->total;
                    else
                        return null;

                })
               
                ->addColumn('status_show', function ($row) {
                    $row->status_show = $row->status;
                    if ($row->status == 'Cancel')
                        $row->status_show = 'Cancelled';
                    elseif ($row->status == 'Approve')
                        $row->status_show = 'Approved';
                    elseif ($row->status == 'Confirm')
                        $row->status_show = 'Confirmed';
                    return $row->status_show;
                })
                ->rawColumns(['action'])
                ->make(true);
        }

        return view('admin.salesinvoice');
    }

    public function create()
    {
        return view('admin.create_salesinvoice');
    }

        // Added for getting the customer details
        public function get_customer_details(Request $request)
        {

            if(isset($request['customer_code']))
            {
                // Fetch the customer details
                $data = Customer::where('customer_code', $request['customer_code'])
                                ->where('is_active', 1)
                                ->first();
        
                // Fetch the quotations related to the customer
                $sales_order = DB::table('sales_order_masters as s')
                                ->join('sales_order_items as st', 's.id', '=', 'st.sm_id')
                                ->where('s.status', 'Open')
                                ->where('s.branch', session('branch_code'))
                                ->where('s.cid', $request['customer_code'])
                                ->select('s.id', 's.doc_num')
                                ->groupBy('s.id', 's.doc_num')
                                ->get();
        
                // Return both the customer details and quotations in the JSON response
                return response()->json([
                    'customer' => $data,
                    'salesorder' => $sales_order
                ]);
            }
        }


        // Added for getting the customer open quotations
    public function get_customer_open_salesorders(Request $request)
    {
        if(isset($request['customer_code']))
        {
            $query = DB::table('sales_order_masters as s')
            ->join('sales_order_items as st', 's.id', '=', 'st.sm_id')
            ->where('s.status', 'Open')
            ->where('s.branch', session('branch_code'))
            ->where('s.cid', $request['customer_code'])
            ->where(function ($query) {
                $query->where('st.status', '<>', 'Cancel')
                    ->where('st.status', '<>', 'Confirm')
                    ->where('st.open_qty', '<>', 0);
            })
            ->select('s.id', 's.doc_num')
            ->groupBy('s.id', 's.doc_num')
            ->get();
            // dd($query->toSql(), $query->getBindings());
                return response()->json($query);
        }
    }   

    public function edit($id)
    {
        $details = SalesInvoiceMaster::select('sales_invoice_masters.*')->with(array('Item_details.products.stock','customer','referral1','referral2','referral3'))->find($id); 
        return view('admin.edit_salesorder', compact('details'));
    }

    public function get_users(Request $request)//get Users
    {
        $data = [];
        $page = $request->page;
        $resultCount = 25;
        $offset = ($page - 1) * $resultCount;
        /** search the users by name,phone and email**/
        if ($request->has('q') && $request->q!= '') {
            $search = $request->q;
            $data = User::select("*")
            ->orWhere('name','LIKE',"%$search%")
            ->orWhere('email','LIKE',"%$search%")->skip($offset)->take($resultCount)->get();

            $count = User::select("id","phone","name")
            ->orWhere('name','LIKE',"%$search%")
            ->orWhere('email','LIKE',"%$search%")->count();
        }
        else{
        /** get the users**/
        $data = User::select("*")->skip($offset)->take($resultCount)->get();
        $count =User::select("id","phone","name")->count();
        }
        /**set pagination**/
        $endCount = $offset + $resultCount;
        if($endCount >= $count)
            $morePages = false;
        else
            $morePages = true;
            
        $result = array(
        "data" => $data,
        "pagination" => array(
        "more" => $morePages
        )
        );
        return response()->json($result);
       
    }
    
    public function get_customers(Request $request)//get Customers
    {
        $data = [];
        $page = $request->page;
        $resultCount = 25;
        $offset = ($page - 1) * $resultCount;
        /** search the users by name,phone and email**/
        if ($request->has('q') && $request->q!= '') {
            $search = $request->q;
            $data = Customer::select("*")->where('is_active',1)
            ->where(function($query) use ($search){$query->where('name','LIKE',"%$search%")
            ->orWhere('phone','LIKE',"%$search%");
            })
            ->skip($offset)->take($resultCount)->get();

            $count = Customer::select("id","phone","name")
            ->where('is_active',1)
            ->where(function($query) use ($search){$query->where('name','LIKE',"%$search%")
            ->orWhere('phone','LIKE',"%$search%");
            })->count();

        }
        else{
        /** get the users**/
        $data = Customer::select("*")->where('is_active',1)->skip($offset)->take($resultCount)->get();

        $count =Customer::select("id","phone","name")->where('is_active',1)->count();
        }
        /**set pagination**/
        $endCount = $offset + $resultCount;
        if($endCount >= $count)
            $morePages = false;
        else
            $morePages = true;
            
        $result = array(
        "data" => $data,
        "pagination" => array(
        "more" => $morePages
        )
        );
        return response()->json($result);
       
    }
    
    public function get_partners(Request $request, $type)//get Partners
    {
        $data = [];
        $page = $request->page;
        $resultCount = 25;
        $offset = ($page - 1) * $resultCount;
        /** search the users by name,phone and email**/
        if ($request->has('q') && $request->q!= '') {
            $search = $request->q;
            $data = Partner::select("*")->where('partner_type',$type)
            ->where(function ($query) use ($search) {
                $query->where('name','LIKE',"%$search%")
                      ->orWhere('phone','LIKE',"%$search%");
            })->skip($offset)->take($resultCount)->get();

            $count = Partner::select("id","phone","name")->where('partner_type',$type)
            ->where(function ($query) use ($search) {
                $query->where('name','LIKE',"%$search%")
                      ->orWhere('phone','LIKE',"%$search%");
            })->count();

        }
        else{
        /** get the users**/
        $data = Partner::select("*")->where('partner_type',$type)->skip($offset)->take($resultCount)->get();

        $count =Partner::select("id","phone","name")->where('partner_type',$type)->count();
        }
        /**set pagination**/
        $endCount = $offset + $resultCount;
        if($endCount >= $count)
            $morePages = false;
        else
            $morePages = true;
            
        $result = array(
        "data" => $data,
        "pagination" => array(
        "more" => $morePages
        )
        );
        return response()->json($result);
       
    }
    
    public function get_products(Request $request)//get Products
    {
        $data = [];
        $page = $request->page;
        $resultCount = 25;
        $offset = ($page - 1) * $resultCount;
        /** search the products by name**/
        if ($request->has('q') && $request->q!= '') {
            $search = $request->q;
            $data = Product::select("productCode","productName")
            ->where('is_active','Y')
            ->where(function ($query) use ($search) {
                $query->where('productName','LIKE',"%$search%")
                      ->orWhere('productCode','LIKE',"%$search%");
            })->skip($offset)->with('category','stock.warehouse')->take($resultCount)->get();

            $count = Product::select("id","phone","name")
            ->where('is_active','Y')
            ->where(function ($query) use ($search) {
                $query->where('productName','LIKE',"%$search%")
                      ->orWhere('productCode','LIKE',"%$search%");
            })->count();

        }
        else{
        /** get the users**/
        $data = Product::select("productCode","productName")->where('is_active','Y')->with('category','stock.warehouse')->skip($offset)->take($resultCount)->get();

        $count =Product::select("productCode","productName")->where('is_active','Y')->count();
        }
        /**set pagination**/
        $endCount = $offset + $resultCount;
        if($endCount >= $count)
            $morePages = false;
        else
            $morePages = true;
            
        $result = array(
        "data" => $data,
        "pagination" => array(
        "more" => $morePages
        )
        );
        return response()->json($result);
       
    }

    public function get_warehouses(Request $request)
    {
        $data = [];
        $page = $request->page;
        $productCode = $request->productCode;
        $resultCount = 25;
        $offset = ($page - 1) * $resultCount;
        /** search the products by name**/
        if ($request->has('q') && $request->q!= '') {
            $search = $request->q;
            $data = ProductStock::
            with('warehouse')->whereHas('warehouse', function ($query) use ($search) {
                $query->where('whsName','LIKE',"%$search%");
                $query->orWhere('whsCode','LIKE',"%$search%");
                return $query;
            })->where('productCode',$productCode)   
            ->skip($offset)->take($resultCount)->get();

            $count = ProductStock::select("*")->
            with(['warehouse' => function($query) use ($search) {
                $query->select('whsCode', 'whsName');
                $query->orWhere('whsName','LIKE',"%$search%");
                $query->orWhere('whsCode','LIKE',"%$search%");
            }])->where('productCode',$productCode)
            ->count();

        }
        else{
        /** get the users**/
        $data = ProductStock::select("*")->
        with(['warehouse','product'])->where('productCode',$productCode)->skip($offset)->take($resultCount)->get();

        $count =ProductStock::select("productCode","productName")->count();
        }
        /**set pagination**/
        $endCount = $offset + $resultCount;
        if($endCount >= $count)
            $morePages = false;
        else
            $morePages = true;
            
        $result = array(
        "data" => $data,
        "pagination" => array(
        "more" => $morePages
        )
        );
        return response()->json($result);
    }

    public function get_product_stock(Request $request)
    {
        $product = ProductStock::with('warehouse','product')->where('productCode',$request->productCode)->first();
        //->where('whsCode',$request->whsCode)
        $product['price_list'] = ProductPrice::where('productCode',$request->productCode)->first();
        return response()->json($product);
    }

    public function update(Request $request,$quotation_id)
    {
        $validator = $request->validate( [
            'product' => 'required|array|min:1',
            'quantity' => 'required|array|min:1']);
        $quotation = SalesOrder::find($quotation_id);
        $quotation->CustomerCode = $request->customer;
        //$quotation->user_id = Auth::user()->id;
        $quotation->Ref1 = $request->partner1;
        $quotation->Ref2 = $request->partner2;
        $quotation->Ref3 = $request->partner3;
        $quotation->DocDate = $request->date;
        $quotation->DueDate = $request->DueDate;
        $quotation->PriceList = $request->priceList;
        $quotation->VehType = $request->vehicle_type;
        $quotation->Distance = $request->km;
        $quotation->Remarks = $request->remarks;
        $quotation->DiscPrcnt = $request->discountPercent;
        $quotation->TaxAmount = $request->tax_amount;
        $quotation->DocTotal = $request->grand_total;
        $quotation->FreightCharge = $request->FreightCharge;
        $quotation->LoadingCharge = $request->LoadingCharge;
        $quotation->UnloadingCharge = $request->UnloadingCharge;
        $quotation->save();
        $products = $request->product; 
        $line_ids = $request->line_id; 
        $p = salesinvoiceItem::whereNotIn('id', $line_ids)->where('quotation_id',$quotation_id)->delete();
        //print_r(($p)); exit;       
        $warehouses = $request->warehouse;        
        $quantity = $request->quantity;      
        $select_uom = $request->select_uom;      
        $disc_perct = $request->disc_perct; 
        $LineDiscPrice = $request->LineDiscPrice;
        $discount_type = $request->discount_type;  
        $LineTotal = $request->LineTotal;    
        $grandTotal = $request->grand_total;
        $area = $request->area;
        $count = count($products);
        $lineNo = 1;$grand_total = 0;
        for($i=0; $i<$count; $i++)
        {
            if(!$quantity[$i])
                $quantity[$i] = 1;
                
            if(!empty($products[$i]) && !empty($quantity[$i]) && !empty($warehouses[$i]))
            {
                $quotationItem = salesinvoiceItem::where(array('quotation_id'=>$quotation_id,'id'=>$line_ids[$i]))->first();                
                $item = Product::where('productCode',$products[$i])->first();
                if(!empty($quotationItem))
                {
                    $price = $quotationItem->UnitPrice;
                    $taxRate = $quotationItem->TaxRate;
                }
                elseif(!empty($item))
                {
                    $quotationItem = new salesinvoiceItem;
                    $quotationItem->quotation_id = $quotation_id;
                    $quotationItem->ItemCode = $products[$i];
                    $quotationItem->whsCode = $warehouses[$i];

                    $price_list = ProductPrice::where('productCode',$products[$i])->where('priceList',$request->priceList)->first();
                    $quotationItem->UnitPrice = $price = $price_list->price;
                    $quotationItem->TaxRate = $taxRate = $item->taxRate;
                }
                $quotationItem->Qty = $quantity[$i];
                $quotationItem->area = $area[$i];                
                $quotationItem->DiscType = $discount_type[$i];

                $quotationItem->UOM = $item->invUOM;
                if(!$item->sqft_Conv)
                    $item->sqft_Conv = 1;
                $item->sqft_Conv = round($item->sqft_Conv,3);
                $quotationItem->SqmtQty = $quantity[$i] * $item->conv_Factor;
                $quotationItem->SqftQty = $quantity[$i] * $item->sqft_Conv;
                
                if($discount_type[$i] == 'Percentage')
                {                            
                    $quotationItem->LineDiscPrcnt = $disc_perct[$i];
                    $quotationItem->PerSqftDisc = round($price/$item->sqft_Conv,4);  
                    $quotationItem->LineDiscPrice = round($LineDiscPrice[$i]*100/($taxRate+100),4); 
                    $quotationItem->PriceAfterDisc = round(($price - $price * $disc_perct[$i]/100) * $quantity[$i],2);
                }                           
                
                else
                {
                    $quotationItem->PerSqftDisc = round($disc_perct[$i]*100/($taxRate+100),4);  
                    $quotationItem->LineDiscPrice = round($LineDiscPrice[$i]*100/($taxRate+100),4);                      
                    $quotationItem->PriceAfterDisc = round($price * $quantity[$i] - $quotationItem->LineDiscPrice,2); 
                }
                $quotationItem->TaxAmount = round($quotationItem->PriceAfterDisc * $taxRate/100,2);
                $quotationItem->PriceAfterDisc = round($quotationItem->PriceAfterDisc/$quantity[$i],2);
                $quotationItem->LineTotal = round($LineTotal[$i] * 100/($taxRate+100),2);
                $grand_total = $grand_total + $quotationItem->LineTotal;
                $quotationItem->LineNo = $lineNo;
                $quotationItem->save();
                $lineNo++;
            }
        }
        if(!empty($taxRate))
            $quotation->DiscAmount = round($request->discount_amount*100/($taxRate+100),2);        
        else
            $quotation->DiscAmount = round($request->discount_amount,2);
        /*if(!empty($grandTotal) && !empty($taxRate))
        {
            $quotation->DocTotal = round($grandTotal * 100/($taxRate+100),2);
        }
        else
        {*/
            $DocTotal = $grand_total+$quotation->FreightCharge+$quotation->LoadingCharge+$quotation->UnloadingCharge;
            $quotation->DocTotal = round($DocTotal,2);
        //}
        $quotation->save();
        return redirect('admin/quotations/'.$quotation_id)->with('success','Quotation updated successfully');
    }    

    public function insert(Request $request)
    {
        //dd($request);
        $validator = $request->validate([
            'customer' => 'required', 
            'product' => 'required|array|min:1',
            'quantity' => 'required|array|min:1'
        ]);

        $docnum = $request->doc_list . "-" . $request->docNumber;
        $latestBillNo = SalesInvoiceMaster::max('bill_no'); 
        $bill_no = $latestBillNo ? $latestBillNo + 1 : 111111;  
        $salesinvoice = new SalesInvoiceMaster;
        $salesinvoice->cid = $request->customer;
        $salesinvoice->ref_no = $request->refno;
        $salesinvoice->bill_no = $bill_no;
        $salesinvoice->address_bill = $request->bill_to_address;
        $salesinvoice->scan_here = $request->scan_here;
        $salesinvoice->doc_num = $docnum;
        $salesinvoice->status = $request->status;
        $salesinvoice->branch = session('branch_code');
        $salesinvoice->posting_date = $request->posting_date;
        $salesinvoice->docdue_date = $request->delivery_date;
        $salesinvoice->doc_date = $request->DocuDate;
        $salesinvoice->payment_term = $request->payment_term;
        $salesinvoice->tax_regno = $request->tax_reg_no;
        $salesinvoice->open_salesorder = $request->open_qutn ? $request->open_qutn : 0;
        $salesinvoice->sales_emp_id = $request->partner3;
        $salesinvoice->remarks = $request->remarks;
        $salesinvoice->total_bf_discount = $request->total_bef_discount;
        $salesinvoice->discount_percent = $request->discount;
        $salesinvoice->discount_amount = $request->discount_amount_value;
        $salesinvoice->total_exp = $request->expense;
        $salesinvoice->tax_amount = $request->tax_amount;
        $salesinvoice->rounding = $request->roundtext;
        $salesinvoice->total = $request->grand_total;
        $salesinvoice->applied_amount = 0;
        $salesinvoice->createdBy = Auth::user()->id;
        $salesinvoice->updatedBy = null;
        $salesinvoice->save();

        $salesinvoice_id = $salesinvoice->id;

        //loyalty point calculation for customer updated by reshma
        $total = $request->grand_total;
        if ($total > 0) {
            $lpoint = $total * (env('LOYALTY_POINT') / 100);
            $lpoint_in_rs = round($lpoint, 2);
       
            $customer = Customer::where('customer_code', $request->customer)->first();
         
            if ($customer) {
                // Ensure loyalty_point is initialized to 0 if NULL
                $currentPoints = $customer->loyalty_point ?? 0;
                
                // Update loyalty_point with the new value
                $customer->update(['loyalty_point' => $currentPoints + $lpoint_in_rs]);
            } 
            // else {
            //     // dd('Customer not found');
            // }
        }
        
        

        // Ensure all the arrays are treated properly
        $quotation_item_id = is_array($request->quotation_item_id) ? $request->quotation_item_id : [];
        $products = is_array($request->product) ? $request->product : [];
        $warehouses = is_array($request->whscode) ? $request->whscode : [];
        $quantity = is_array($request->quantity) ? $request->quantity : [];
        $av_quantity = is_array($request->av_quantity) ? $request->av_quantity : [];
        $LineTotal = is_array($request->linetotal) ? $request->linetotal : [];
        $unitprice = is_array($request->unitprice) ? $request->unitprice : [];
        $discprice = is_array($request->discprice) ? $request->discprice : [];
        $taxcode = is_array($request->taxcode) ? $request->taxcode : [];
        $serialno = is_array($request->serialno) ? $request->serialno : [];
        $warrenty = is_array($request->warrenty) ? $request->warrenty : [];

        $count = count($products);
        $lineNo = 1;
        $grand_total = 0;
        //dd($quotation_item_id);

        for ($i = 0; $i < $count; $i++) {
            if (!isset($quantity[$i]) || !$quantity[$i]) {
                $quantity[$i] = 1;
            }
            
            if (!empty($products[$i]) && !empty($quantity[$i])) {

                error_log("Processing product index $i: Product={$products[$i]}, Quantity={$quantity[$i]}, Warehouse={$warehouses[$i]}");

                if (isset($av_quantity[$i]) && isset($quotation_item_id[$i]) && $av_quantity[$i] != '0' && $quotation_item_id[$i] != '0') 
                {                    
                $balance_qty = $av_quantity[$i] - $quantity[$i];
                    // dd($balance_qty);
                    // Retrieve the first matching record by id
                    $quotationitem = SalesOrderItem::find($quotation_item_id[$i]);

//dd($quotationitem);
                    if ($quotationitem) {
                        if ($balance_qty > 0) {
                            $quotationitem->open_qty = $balance_qty;
                        } else {
                            $quotationitem->open_qty = $balance_qty;
                            $quotationitem->status = 'Confirm';
                        }

                        $quotationitem->save();
                        //  if($balance_qty <= 0)
                        //  {
                        //     $pmaster = DB::table('sales_order_masters')
                        //     ->where('id', $quotationitem->sm_id ?? null)
                        //     ->first();
        
                        //     if ($pmaster) {
                        //         // Explicitly update only the fields you want
                        //         DB::table('sales_order_masters')
                        //             ->where('id', $quotationitem->sm_id)
                        //             ->update(['status' => 'Confirm']); // Update only 'status'
                        //     }    
                        //  }


                    }
                  
        
                    
                }
        
                $salesinvoiceItem = new SalesInvoiceItem;
                $salesinvoiceItem->sm_id = $salesinvoice_id;
                $salesinvoiceItem->order_item_id = $quotation_item_id[$i] ?? 0;
                $salesinvoiceItem->item_id = $products[$i];
                $salesinvoiceItem->whs_code = $warehouses[$i];
                $salesinvoiceItem->qty = $quantity[$i];
                $salesinvoiceItem->open_qty = $quantity[$i];
                $salesinvoiceItem->unit_price = $unitprice[$i];
                $salesinvoiceItem->disc_price = $discprice[$i];
                $salesinvoiceItem->tax_code = $taxcode[$i];
                $salesinvoiceItem->line_total = $LineTotal[$i];
                $salesinvoiceItem->serial_no = $serialno[$i];
                $salesinvoiceItem->save();
            }
        }
        
        session()->flash('success', 'Sales Invoice added successfully');
        // return response()->json([
        //     'success' => true,
        //     'salesorder_id' => $salesinvoice_id,  // Pass the saved Sales Order ID
        //     'message' => 'Sales Order added successfully'
        // ]);

        return redirect('admin/sales-invoice/' . $salesinvoice_id)->with('success', 'Sales Invoice added successfully');
    }



    
    public function get_salesorder_details(Request $request)
    {
        if ($request->ajax()) {

            $sorderId = $request['salesorder'];

            // $salesorders = SalesOrderMaster::with([
            //     'items' => function($query) {
            //         $query->where('status', '!=', 'Cancel');
            //     },
            //     'items.products.stock.warehouse',
            //     'customer',
            //     'referral1',
            //     'referral2'
            // ])->whereIn('sales_order_masters.id', $sorderId)->get();



            $salesorders = DB::table('sales_order_masters')
                ->join('sales_order_items', 'sales_order_masters.id', '=', 'sales_order_items.sm_id')
                ->join('partners', 'sales_order_masters.sales_emp_id', '=', 'partners.partner_code')
                ->join('products', 'sales_order_items.item_id', '=', 'products.productCode')
                ->join('product_stocks', 'products.productCode', '=', 'product_stocks.productCode')
                ->join('warehouses', 'product_stocks.whsCode', '=', 'warehouses.whsCode')
                ->join('customers', 'sales_order_masters.cid', '=', 'customers.customer_code')
                ->whereIn('sales_order_masters.id', $sorderId) // equivalent to WHERE IN (4, 2)
                // ->where('sales_order_items.status', '=', 'Open')
                ->where(function ($query) {
                    $query->where('sales_order_items.status', '<>', 'Cancel')
                        ->where('sales_order_items.status', '<>', 'Confirm')
                        ->where('sales_order_items.open_qty', '<>', 0);
    
                })
                ->select(
                    'sales_order_masters.*', 
                    'sales_order_items.*', 
                    'products.productCode', 
                    'products.productName', 
                    'product_stocks.whsCode', 
                    'warehouses.whsName', 
                    'customers.*',
                    'sales_order_items.line_total', 
                    'sales_order_items.open_qty', 
                    'sales_order_items.unit_price', 
                    'sales_order_items.tax_code',
                    'sales_order_items.id', 
                    'sales_order_items.serial_no', 
                    'sales_order_items.status',
                    'partners.name',
                    'partners.partner_code'
                )
                ->get();
                // dd($salesorders);
                $responseData = $salesorders->map(function($item) {
                $line_total = round($item->line_total, 2);
                return [
                    'refno' => $item->ref_no,
                    'sales_emp_id' => $item->sales_emp_id,
                    'partner_name' => $item->name,
                    'tax_regno' => $item->tax_regno,
                    'remarks' => $item->remarks,
                    'productCode' => $item->productCode,
                    'productName' => $item->productName,
                    'Qty' => $item->open_qty,
                    'UnitPrice' => round($item->unit_price, 2),
                    'TaxCode' => $item->tax_code,
                    'whsCode' => $item->whsCode,
                    'whsName' => $item->whsName,
                    'LineTotal' => $line_total,
                    'itemid' => $item->id,
                    'serialno' => $item->serial_no, // Placeholder value, replace as needed
                    'status' => $item->status,
                    'action' => '<button class="remove-row btn btn-danger btn-sm" value="' . $item->id . '">Remove</button>'
                ];
            });


            return response()->json(['success' => true, 'data' => $responseData], 200);
        }

        return response()->json(['error' => 'Invalid request.'], 400);
    }


    public function salesinvoice_close_items(Request $request)
    {
        //dd($request);
        $id=$request['item'];
        $quotation_item = SalesOrderItem::find($id);

        $data = '';
        if ($quotation_item) { 
           // $quotation_item->status = 'Cancel';
            $quotation_item->save();
            $data = "Salesorder item is cancelled!";
        }
        echo json_encode($data);
    }

    public function get_salesinvoice_details(Request $request)
    {
        $query = $request->input('query');
        $results = Product::join('product_stocks', 'products.productCode', '=', 'product_stocks.productCode')
        ->join('product_prices', 'products.productCode', '=', 'product_prices.productCode')
        ->join('warehouses', 'product_stocks.whsCode', '=', 'warehouses.whsCode')
        ->join('itemwarehouses', 'product_stocks.productCode', '=', 'itemwarehouses.ItemCode')
        ->where('products.barcode', '=', $query)
        ->where('itemwarehouses.WhsCode', '=', session('branch_code'))
        ->get();
        return response()->json($results);
    }

} 