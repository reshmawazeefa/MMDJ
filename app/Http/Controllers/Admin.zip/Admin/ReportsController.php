<?php

namespace App\Http\Controllers\Admin;

use DataTables;
use App\Http\Controllers\Controller;
//use App\Models\Customer;
//use App\Models\Partner;
use App\Models\User;
use App\Models\Product;
//use App\Models\ProductPrice;
//use App\Models\CustomQuotation;
//use App\Models\Quotation;
//use App\Models\CustomQuotationItem;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Carbon\Carbon;
class ReportsController extends Controller
{
    public function index(Request $request)
    {
        if ($request->ajax()) {
            if(Auth::user()->hasRole('Admin'))
            {
                $data = DB::table('sales_invoice_masters')
            ->join('customers', 'sales_invoice_masters.cid', '=', 'customers.customer_code') // Join with customers table
            ->join('partners', 'sales_invoice_masters.sales_emp_id', '=', 'partners.partner_code') // Join with partners table
            ->select('sales_invoice_masters.*', 'customers.name as customer_name', 'partners.name as partner_name') // Select customer and partner names
            ->orderBy('sales_invoice_masters.id', 'desc'); // Apply orderBy here
            //->get();
                //dd($data);
            }
            else{
                $data = DB::table('sales_invoice_masters')
            ->join('customers', 'sales_invoice_masters.cid', '=', 'customers.customer_code') // Join with customers table
            ->join('partners', 'sales_invoice_masters.sales_emp_id', '=', 'partners.partner_code') // Join with partners table
            ->select('sales_invoice_masters.*', 'customers.name as customer_name', 'partners.name as partner_name') // Select customer and partner names
            ->orderBy('sales_invoice_masters.id', 'desc'); // Apply orderBy here
                //->get();
            }
            //dd($data);
            if(!empty($request->from_date))
            {
                // //dd($request->from_date);
                // //echo "here";
                // $data->where('doc_date','>=', $request->from_date);
                // Convert 'from_date' to dd-mm-yyyy format
                $fromDate = Carbon::createFromFormat('Y-m-d', $request->from_date)->format('d-m-Y');
                $data->where('doc_date', '>=', $fromDate);
            }
            if(!empty($request->to_date))
            {
                //echo "here";
                //$data->where('doc_date','<=', $request->to_date);
                // Convert 'to_date' to dd-mm-yyyy format
                $toDate = Carbon::createFromFormat('Y-m-d', $request->to_date)->format('d-m-Y');
                $data->where('doc_date', '<=', $toDate);
            }
            if(!empty($request->branch))
            {
                $data->where('branch', $request->branch);
            }
            if(!empty($request->customer))
            {
                $data->where('cid', $request->customer);
            }
            if(!empty($request->user))
            {
                //dd($request->user);
                $data->where('sales_emp_id', $request->user);
            }
            //$data->orderBy('id','desc');
            $data = $data->get();
            return Datatables::of($data)
            ->addIndexColumn() // Add SlNo as an index column
            ->addColumn('Type', function ($row) {
                return 'Invoice'; // Return the static value for this column
            })
            ->addColumn('taxableamount', function ($row) {
                // Calculate the total as total_bf_discount - discount_amount
                return round($row->total_bf_discount - $row->discount_amount, 2);
            })
            ->addColumn('customer_name', function ($row) {
                return $row->customer_name; // Display the customer name
            })
            ->addColumn('partner_name', function ($row) {
                return $row->partner_name; // Display the partner name
            })
            ->rawColumns(['Type']) // If the value contains HTML, use rawColumns
            ->make(true);
        }
        
        return view('admin.sales_register');
    }

    public function salesreturnregister(Request $request)
    {

        //dd($request);
        if ($request->ajax()) {
            if(Auth::user()->hasRole('Admin'))
            {
                $data = DB::table('sales_return_masters')
            ->join('customers', 'sales_return_masters.cid', '=', 'customers.customer_code') // Join with customers table
            ->join('partners', 'sales_return_masters.sales_emp_id', '=', 'partners.partner_code') // Join with partners table
            ->select('sales_return_masters.*', 'customers.name as customer_name', 'partners.name as partner_name') // Select customer and partner names
            ->orderBy('sales_return_masters.id', 'desc'); // Apply orderBy here
            //->get();
                //dd($data);
            }
            else{
                $data = DB::table('sales_return_masters')
            ->join('customers', 'sales_return_masters.cid', '=', 'customers.customer_code') // Join with customers table
            ->join('partners', 'sales_return_masters.sales_emp_id', '=', 'partners.partner_code') // Join with partners table
            ->select('sales_return_masters.*', 'customers.name as customer_name', 'partners.name as partner_name') // Select customer and partner names
            ->orderBy('sales_return_masters.id', 'desc'); // Apply orderBy here
                //->get();
            }
       // dd($data->get());
            if(!empty($request->from_date))
            {
                // //dd($request->from_date);
                // //echo "here";
                // $data->where('doc_date','>=', $request->from_date);
                // Convert 'from_date' to dd-mm-yyyy format
                $fromDate = Carbon::createFromFormat('Y-m-d', $request->from_date)->format('d-m-Y');
                $data->where('doc_date', '>=', $fromDate);
            }
            if(!empty($request->to_date))
            {
                //echo "here";
                //$data->where('doc_date','<=', $request->to_date);
                // Convert 'to_date' to dd-mm-yyyy format
                $toDate = Carbon::createFromFormat('Y-m-d', $request->to_date)->format('d-m-Y');
                $data->where('doc_date', '<=', $toDate);
            }
            if(!empty($request->branch))
            {
                $data->where('branch', $request->branch);
            }
            if(!empty($request->rtn_status))
            {
                //$data->where('status', $request->rtn_status);
                if ($request->rtn_status == "All") {
                    $data->where('sales_return_masters.status', '!=', 'Cancel');
                } else {
                    $data->where('sales_return_masters.status', $request->rtn_status);
                }
            }
            if(!empty($request->customer))
            {
                $data->where('cid', $request->customer);
            }
            if(!empty($request->user))
            {
                //dd($request->user);
                $data->where('sales_emp_id', $request->user);
            }
            // dd($data->toSql());
            //$data->orderBy('id','desc');
            $data = $data->get();
            return Datatables::of($data)
            ->addIndexColumn() // Add SlNo as an index column
            ->addColumn('series', function ($row) {
                return 'TRKABH'; // Return the static value for this column
            })
            
            ->addColumn('taxableamount', function ($row) {
                // Calculate the total as total_bf_discount - discount_amount
                return round($row->total_bf_discount - $row->discount_amount, 2);
            })
            ->addColumn('customer_name', function ($row) {
                return $row->customer_name; // Display the customer name
            })
            ->addColumn('partner_name', function ($row) {
                return $row->partner_name; // Display the partner name
            })
            // ->addColumn('remarks', function ($row) {
            //     return $row->remarks ?? 'N/A'; // Add the remarks field or a fallback value
            // })
            ->rawColumns(['series']) // If the value contains HTML, use rawColumns
            ->make(true);
        }
        return view('admin.sales_return_register');
    }


    public function stockregister(Request $request)
    {

      // dd($request);
        if ($request->ajax()) {
            if(Auth::user()->hasRole('Admin'))
            {
                $data = DB::table('product_stocks')
            ->join('products', 'product_stocks.productCode', '=', 'products.productCode') 
            ->select('product_stocks.*', 'products.productName as productName') 
            ->orderBy('product_stocks.id', 'desc'); // Apply orderBy here
            //->get();
                //dd($data);
            }
            else{
                $data = DB::table('product_stocks')
            ->join('products', 'product_stocks.productCode', '=', 'products.productCode') 
            ->select('product_stocks.*', 'products.productName as productName') 
            ->orderBy('product_stocks.id', 'desc'); // Apply orderBy here
                //->get();
            }
       // dd($data->get());
            if(!empty($request->from_date))
            {
                $fromDate = Carbon::createFromFormat('Y-m-d', $request->from_date)->format('Y-m-d');
                $data->where('product_stocks.updated_date', '>=', $fromDate);
            }
            if(!empty($request->to_date))
            {
                $toDate = Carbon::createFromFormat('Y-m-d', $request->to_date)->format('Y-m-d');
                $data->where('product_stocks.updated_date', '<=', $toDate);
            }
            if(!empty($request->products))
            {
                $data->where('product_stocks.productCode', $request->products);
            }
            
            // dd($data->toSql());
            //$data->orderBy('id','desc');
            $data = $data->get();
            return Datatables::of($data)
            ->addIndexColumn() // Add SlNo as an index column
            // ->addColumn('group_name', function ($row) {
            //     return 'Test Group Name'; // Return the static value for this column
            // })
            
            ->addColumn('item_name', function ($row) {
                return $row->productName; // Display the customer name
            })

            ->rawColumns([]) // If the value contains HTML, use rawColumns
            ->make(true);
        }
        return view('admin.stock_register');
    }


    public function get_all_products(Request $request)//get Products
    {
        // dd("hu");
        $data = [];
        $page = $request->page;
        $resultCount = 25;
        $offset = ($page - 1) * $resultCount;
        /** search the products by name**/
        if ($request->has('q') && $request->q!= '') {
            // dd("hi");

            $search = $request->q;
            $data = Product::select("productCode","productName","barcode")
            ->where('is_active','Y')
            ->where(function ($query) use ($search) {
                $query->where('productName','LIKE',"%$search%")
                      ->orWhere('productCode','LIKE',"%$search%");
            })->skip($offset)->with('category','stock.warehouse')->take($resultCount)->get();

            $count = Product::select("id","phone","name")
            ->where('is_active','Y')
            ->where(function ($query) use ($search) {
                $query->where('productName','LIKE',"%$search%")
                      ->orWhere('productCode','LIKE',"%$search%");
            })->count();

        }
        else{

        $data = Product::select("productCode", "productName", "barcode")
                    ->where('is_active', 'Y')
                    ->with('category', 'stock.warehouse')
                    ->skip($offset)
                    ->take($resultCount)->get();

        $count =Product::select("productCode","productName","barcode")->where('is_active','Y')->with('category', 'stock.warehouse')->count();
        }
        /**set pagination**/
        $endCount = $offset + $resultCount;
        if($endCount >= $count)
            $morePages = false;
        else
            $morePages = true;
            
        $result = array(
        "data" => $data,
        "pagination" => array(
        "more" => $morePages
        )
        );
        return response()->json($result);
       
    }
 
    public function item_history(Request $request)
    {
       // dd($request);
        if ($request->ajax()) {
            if(Auth::user()->hasRole('Admin'))
            {
                $data = DB::table('purchase_order_masters as A')
                ->join('purchase_order_items as B', 'A.id', '=', 'B.sm_id')
                ->join('products as C', 'B.item_id', '=', 'C.productCode')
                ->join('partners as D', 'A.sales_emp_id', '=', 'D.partner_code')
            
                ->select([
                    'A.id as TransNo',
                    'A.obj_type as TransType',
                    'A.sales_emp_id as CardCode',
                    'D.name as CardName',
                    'A.doc_num as LineID',
                    'A.doc_date as DocDate',
                    'B.item_id as ItemCode',
                    'C.productName as ItemName',
                    'B.open_qty as InQty',
                    DB::raw('0 as OutQty'),
                    'B.disc_price as Price',
                    'A.branch as BranchCode',
                    'B.whs_code as WhsCode',
                ])
                ->unionAll(
                    DB::table('goods_return_masters as A')
                        ->join('goods_return_items as B', 'A.id', '=', 'B.sm_id')
                        ->join('products as C', 'B.item_id', '=', 'C.productCode')
                        ->join('partners as D', 'A.sales_emp_id', '=', 'D.partner_code')
                    
                        ->select([
                            'A.id as TransNo',
                            'A.obj_type as TransType',
                            'A.sales_emp_id as CardCode',
                            'D.name as CardName',
                            'A.doc_num as LineID',
                            'A.doc_date as DocDate',
                            'B.item_id as ItemCode',
                            'C.productName as ItemName',
                            DB::raw('0 as InQty'),
                            'B.open_qty as OutQty',
                            'B.disc_price as Price',
                            'A.branch as BranchCode',
                            'B.whs_code as WhsCode',
                        ])
                )
                ->unionAll(
                    DB::table('purchase_invoice_masters as A')
                        ->join('purchase_invoice_items as B', 'A.id', '=', 'B.sm_id')
                        ->join('products as C', 'B.item_id', '=', 'C.productCode')
                        ->join('partners as D', 'A.sales_emp_id', '=', 'D.partner_code')
            
                        ->select([
                            'A.id as TransNo',
                            'A.obj_type as TransType',
                            'A.sales_emp_id as CardCode',
                            'D.name as CardName',
                            'A.doc_num as LineID',
                            'A.doc_date as DocDate',
                            'B.item_id as ItemCode',
                            'C.productName as ItemName',
                            DB::raw('CASE WHEN B.base_type != 20 THEN B.open_qty ELSE 0 END as InQty'),
                            DB::raw('0 as OutQty'),
                            'B.disc_price as Price',
                            'A.branch as BranchCode',
                            'B.whs_code as WhsCode',
                        ])
                )
                ->unionAll(
                    DB::table('purchase_return_masters as A')
                        ->join('purchase_return_items as B', 'A.id', '=', 'B.sm_id')
                        ->join('products as C', 'B.item_id', '=', 'C.productCode')
                        ->join('partners as D', 'A.sales_emp_id', '=', 'D.partner_code')
            
                        ->select([
                            'A.id as TransNo',
                            'A.obj_type as TransType',
                            'A.sales_emp_id as CardCode',
                            'D.name as CardName',
                            'A.doc_num as LineID',
                            'A.doc_date as DocDate',
                            'B.item_id as ItemCode',
                            'C.productName as ItemName',
                            DB::raw('0 as InQty'),
                            'B.open_qty as OutQty',
                            'B.disc_price as Price',
                            'A.branch as BranchCode',
                            'B.whs_code as WhsCode',
                        ])
                )
                   ->unionAll(
                    DB::table('sales_invoice_masters as A')
                        ->join('sales_invoice_items as B', 'A.id', '=', 'B.sm_id')
                        ->join('products as C', 'B.item_id', '=', 'C.productCode')
                        ->join('partners as D', 'A.sales_emp_id', '=', 'D.partner_code')
                        ->select([
                            'A.id as TransNo',
                            'A.obj_type as TransType',
                            'A.sales_emp_id as CardCode',
                            'D.name as CardName',
                            'A.doc_num as LineID',
                            'A.doc_date as DocDate',
                            'B.item_id as ItemCode',
                            'C.productName as ItemName',
                            DB::raw('0 as InQty'),
                            DB::raw('CASE WHEN B.base_type != 15 THEN B.open_qty ELSE 0 END as OutQty'),
                            'B.disc_price as Price',
                            'A.branch as BranchCode',
                            'B.whs_code as WhsCode',
                        ])
                )
                ->unionAll(
                    DB::table('sales_return_masters as A')
                        ->join('sales_return_items as B', 'A.id', '=', 'B.sm_id')
                        ->join('products as C', 'B.item_id', '=', 'C.productCode')
                        ->join('partners as D', 'A.sales_emp_id', '=', 'D.partner_code')
            
                        ->select([
                            'A.id as TransNo',
                            'A.obj_type as TransType',
                            'A.sales_emp_id as CardCode',
                            'D.name as CardName',
                            'A.doc_num as LineID',
                            'A.doc_date as DocDate',
                            'B.item_id as ItemCode',
                            'C.productName as ItemName',
                            'B.open_qty as InQty',
                            DB::raw('0 as OutQty'),
                            'B.disc_price as Price',
                            'A.branch as BranchCode',
                            'B.whs_code as WhsCode',
                        ])
                )
                ->unionAll(
                    DB::table('stock_in_masters as A')
                        ->join('stock_in_items as B', 'A.id', '=', 'B.sm_id')
                        ->join('products as C', 'B.item_id', '=', 'C.productCode')
                        ->select([
                            'A.id as TransNo',
                            'A.obj_type as TransType',
                            'A.from_branch as CardCode',
                            'A.from_branch_name as CardName',
                            'A.doc_number as LineID',
                            'A.doc_date as DocDate',
                            'B.item_id as ItemCode',
                            'C.productName as ItemName',
                            'B.open_qty as InQty',
                            DB::raw('0 as OutQty'),
                            'B.unit_price as Price',
                            'A.to_branch as BranchCode',
                            'B.whscode as WhsCode',
                        ])
                )
                ->unionAll(
                    DB::table('stock_out_masters as A')
                        ->join('stock_out_items as B',  'A.id', '=', 'B.sm_id')
                        ->join('products as C', 'B.item_id', '=', 'C.productCode')
                        ->select([
                            'A.id as TransNo',
                            'A.obj_type as TransType',
                            'A.to_branch as CardCode',
                            'A.to_branch_name as CardName',
                            'A.doc_number as LineID',
                            'A.doc_date as DocDate',
                            'B.item_id as ItemCode',
                            'C.productName as ItemName',
                            DB::raw('0 as InQty'),
                            'B.open_qty as OutQty',
                            'B.unit_price as Price',
                            'A.from_branch as BranchCode',
                            'B.whscode as WhsCode',
                        ])
                ); 
            }
            else{
                $data = DB::table('purchase_order_masters as A')
                ->join('purchase_order_items as B', 'A.id', '=', 'B.sm_id')
                ->join('products as C', 'B.item_id', '=', 'C.productCode')
                ->join('partners as D', 'A.sales_emp_id', '=', 'D.partner_code')
    
                ->select([
                    'A.id as TransNo',
                    'A.obj_type as TransType',
                    'A.sales_emp_id as CardCode',
                    'D.name as CardName',
                    'A.doc_num as LineID',
                    'A.doc_date as DocDate',
                    'B.item_id as ItemCode',
                    'C.productName as ItemName',
                    'B.open_qty as InQty',
                    DB::raw('0 as OutQty'),
                    'B.disc_price as Price',
                    'A.branch as BranchCode',
                    'B.whs_code as WhsCode',
                ])
                ->unionAll(
                    DB::table('goods_return_masters as A')
                        ->join('goods_return_items as B', 'A.id', '=', 'B.sm_id')
                        ->join('products as C', 'B.item_id', '=', 'C.productCode')
                        ->join('partners as D', 'A.sales_emp_id', '=', 'D.partner_code')
                    
                        ->select([
                            'A.id as TransNo',
                            'A.obj_type as TransType',
                            'A.sales_emp_id as CardCode',
                            'D.name as CardName',
                            'A.doc_num as LineID',
                            'A.doc_date as DocDate',
                            'B.item_id as ItemCode',
                            'C.productName as ItemName',
                            DB::raw('0 as InQty'),
                            'B.open_qty as OutQty',
                            'B.disc_price as Price',
                            'A.branch as BranchCode',
                            'B.whs_code as WhsCode',
                        ])
                )
                ->unionAll(
                    DB::table('purchase_invoice_masters as A')
                        ->join('purchase_invoice_items as B', 'A.id', '=', 'B.sm_id')
                        ->join('products as C', 'B.item_id', '=', 'C.productCode')
                        ->join('partners as D', 'A.sales_emp_id', '=', 'D.partner_code')
    
                        ->select([
                            'A.id as TransNo',
                            'A.obj_type as TransType',
                            'A.sales_emp_id as CardCode',
                            'D.name as CardName',
                            'A.doc_num as LineID',
                            'A.doc_date as DocDate',
                            'B.item_id as ItemCode',
                            'C.productName as ItemName',
                            DB::raw('CASE WHEN B.base_type != 20 THEN B.open_qty ELSE 0 END as InQty'),
                            DB::raw('0 as OutQty'),
                            'B.disc_price as Price',
                            'A.branch as BranchCode',
                            'B.whs_code as WhsCode',
                        ])
                )
                ->unionAll(
                    DB::table('purchase_return_masters as A')
                        ->join('purchase_return_items as B', 'A.id', '=', 'B.sm_id')
                        ->join('products as C', 'B.item_id', '=', 'C.productCode')
                        ->join('partners as D', 'A.sales_emp_id', '=', 'D.partner_code')
    
                        ->select([
                            'A.id as TransNo',
                            'A.obj_type as TransType',
                            'A.sales_emp_id as CardCode',
                            'D.name as CardName',
                            'A.doc_num as LineID',
                            'A.doc_date as DocDate',
                            'B.item_id as ItemCode',
                            'C.productName as ItemName',
                            DB::raw('0 as InQty'),
                            'B.open_qty as OutQty',
                            'B.disc_price as Price',
                            'A.branch as BranchCode',
                            'B.whs_code as WhsCode',
                        ])
                )
                ->unionAll(
                    DB::table('sales_invoice_masters as A')
                        ->join('sales_invoice_items as B', 'A.id', '=', 'B.sm_id')
                        ->join('products as C', 'B.item_id', '=', 'C.productCode')
                        ->join('partners as D', 'A.sales_emp_id', '=', 'D.partner_code')
                        ->select([
                            'A.id as TransNo',
                            'A.obj_type as TransType',
                            'A.sales_emp_id as CardCode',
                            'D.name as CardName',
                            'A.doc_num as LineID',
                            'A.doc_date as DocDate',
                            'B.item_id as ItemCode',
                            'C.productName as ItemName',
                            DB::raw('0 as InQty'),
                            DB::raw('CASE WHEN B.base_type != 15 THEN B.open_qty ELSE 0 END as OutQty'),
                            'B.disc_price as Price',
                            'A.branch as BranchCode',
                            'B.whs_code as WhsCode',
                        ])
                )
                ->unionAll(
                    DB::table('sales_return_masters as A')
                        ->join('sales_return_items as B', 'A.id', '=', 'B.sm_id')
                        ->join('products as C', 'B.item_id', '=', 'C.productCode')
                        ->join('partners as D', 'A.sales_emp_id', '=', 'D.partner_code')
    
                        ->select([
                            'A.id as TransNo',
                            'A.obj_type as TransType',
                            'A.sales_emp_id as CardCode',
                            'D.name as CardName',
                            'A.doc_num as LineID',
                            'A.doc_date as DocDate',
                            'B.item_id as ItemCode',
                            'C.productName as ItemName',
                            'B.open_qty as InQty',
                            DB::raw('0 as OutQty'),
                            'B.disc_price as Price',
                            'A.branch as BranchCode',
                            'B.whs_code as WhsCode',
                        ])
                )
                ->unionAll(
                    DB::table('stock_in_masters as A')
                        ->join('stock_in_items as B', 'A.id', '=', 'B.sm_id')
                        ->join('products as C', 'B.item_id', '=', 'C.productCode')
                        ->select([
                            'A.id as TransNo',
                            'A.obj_type as TransType',
                            'A.from_branch as CardCode',
                            'A.from_branch_name as CardName',
                            'A.doc_number as LineID',
                            'A.doc_date as DocDate',
                            'B.item_id as ItemCode',
                            'C.productName as ItemName',
                            'B.open_qty as InQty',
                            DB::raw('0 as OutQty'),
                            'B.unit_price as Price',
                            'A.to_branch as BranchCode',
                            'B.whscode as WhsCode',
                        ])
                )
                ->unionAll(
                    DB::table('stock_out_masters as A')
                        ->join('stock_out_items as B',  'A.id', '=', 'B.sm_id')
                        ->join('products as C', 'B.item_id', '=', 'C.productCode')
                        ->select([
                            'A.id as TransNo',
                            'A.obj_type as TransType',
                            'A.to_branch as CardCode',
                            'A.to_branch_name as CardName',
                            'A.doc_number as LineID',
                            'A.doc_date as DocDate',
                            'B.item_id as ItemCode',
                            'C.productName as ItemName',
                            DB::raw('0 as InQty'),
                            'B.open_qty as OutQty',
                            'B.unit_price as Price',
                            'A.from_branch as BranchCode',
                            'B.whscode as WhsCode',
                        ])
                ); 
            }

             $data = DB::table(DB::raw("({$data->toSql()}) as sub"))
            ->mergeBindings($data);

        // Apply filters
        if(!empty($request->from_date))
        {
            $fromDate = Carbon::createFromFormat('Y-m-d', $request->from_date)->format('d-m-Y');
            $data->where('DocDate', '>=', $fromDate);
        }
        if(!empty($request->to_date))
        {
            $toDate = Carbon::createFromFormat('Y-m-d', $request->to_date)->format('d-m-Y');
            $data->where('DocDate', '<=', $toDate);
        }

        if (!empty($request->item)) {
            $data->where('ItemCode', $request->item);
        }

        $data = $data->get(); // Fetch results as a collection
        Log::info($data); 
        // Ensure the collection is not empty before summing
        $totalInQty = $data->isNotEmpty() ? $data->sum('InQty') : 0;
        $totalOutQty = $data->isNotEmpty() ? $data->sum('OutQty') : 0;    
        
        
        return Datatables::of($data)
            ->addIndexColumn() // Add SlNo as an index column
            ->with('totalInQty', $totalInQty) // Pass total InQty
            ->with('totalOutQty', $totalOutQty) // Pass total OutQty
            ->make(true);
        
        }
        return view('admin.item_history');
    }


    public function cashbook(Request $request)
    {
        if ($request->ajax()) {
            if (Auth::user()->hasRole('Admin')) {
                $query = DB::table('incoming_payment_masters as Inc')
                    ->selectRaw("DocDate, DocNum, CardCode, 
                        CASE WHEN IFNULL(CardName, '') = '' THEN Inc2.AcctName ELSE IFNULL(CardName, '') END AS CardName,
                        CASE 
                            WHEN DocType = 'A' THEN Inc2.SumApplied 
                            ELSE CASE 
                                WHEN CashSum != 0 THEN CashSum 
                                WHEN CheckSum != 0 THEN CheckSum 
                                WHEN TransSum != 0 THEN TransSum 
                                ELSE CardSum END 
                        END AS Debit,
                        0 AS Credit, CashAcct,
                        IFNULL((SELECT InvDocNum FROM incomingpayments_lines Inc1 WHERE Inc1.DocEntry = Inc.DocEntry LIMIT 1), 0) AS InvNo")
                    ->leftJoin('incomingpayments_lines2 as Inc2', 'Inc.DocEntry', '=', 'Inc2.DocEntry')
                    ->where('Inc.Branch', session('branch_code'));
    
                $unionQuery = DB::table('outgoing_payment_masters as Inc')
                    ->selectRaw("DocDate, DocNum, Inc2.AcctName AS CardCode, 
                        Inc2.AcctName AS CardName,
                        0 AS Debit, Inc2.SumApplied AS Credit, CashAcct, 
                        0 AS InvNo")
                    ->join('outgoingpayments_lines2 as Inc2', 'Inc.DocEntry', '=', 'Inc2.DocEntry')
                    ->where('Inc.Branch', session('branch_code'));
            } else {
                $query = DB::table('incoming_payment_masters as Inc')
                    ->selectRaw("DocDate, DocNum, CardCode, 
                        CASE WHEN IFNULL(CardName, '') = '' THEN Inc2.AcctName ELSE IFNULL(CardName, '') END AS CardName,
                        CASE 
                            WHEN DocType = 'A' THEN Inc2.SumApplied 
                            ELSE CASE 
                                WHEN CashSum != 0 THEN CashSum 
                                WHEN CheckSum != 0 THEN CheckSum 
                                WHEN TransSum != 0 THEN TransSum 
                                ELSE CardSum END 
                        END AS Debit,
                        0 AS Credit, CashAcct,
                        IFNULL((SELECT InvDocNum FROM incomingpayments_lines inc1 WHERE Inc1.DocEntry = Inc.DocEntry LIMIT 1), 0) AS InvNo")
                    ->leftJoin('incomingpayments_lines2 as Inc2', 'Inc.DocEntry', '=', 'Inc2.DocEntry')
                    ->where('Inc.Branch', session('branch_code'));
    
                $unionQuery = DB::table('outgoing_payment_masters as Inc')
                    ->selectRaw("DocDate, DocNum, Inc2.AcctName AS CardCode, 
                        Inc2.AcctName AS CardName,
                        0 AS Debit, Inc2.SumApplied AS Credit, CashAcct, 
                        0 AS InvNo")
                    ->join('outgoingpayments_lines2 as Inc2', 'Inc.DocEntry', '=', 'Inc2.DocEntry')
                    ->where('Inc.Branch', session('branch_code'));
            }
    
            if (!empty($request->from_date)) {
                $query->whereRaw("DATE_FORMAT(Inc.DocDate, '%Y-%m-%d') >= ?", [$request->from_date]);
                $unionQuery->whereRaw("DATE_FORMAT(Inc.DocDate, '%Y-%m-%d') >= ?", [$request->from_date]);
            }
    
            if (!empty($request->to_date)) {
                $query->whereRaw("DATE_FORMAT(Inc.DocDate, '%Y-%m-%d') <= ?", [$request->to_date]);
                $unionQuery->whereRaw("DATE_FORMAT(Inc.DocDate, '%Y-%m-%d') <= ?", [$request->to_date]);
            }
    
            if (!empty($request->account)) {
                $query->whereRaw("$request->account = CASE 
                    WHEN CashSum != 0 THEN CashAcct 
                    WHEN CheckSum != 0 THEN CheckAcct 
                    WHEN TransSum != 0 THEN TransAcct 
                    ELSE CardAcct END");
                $unionQuery->where('Inc2.AcctCode', $request->account);
            }
    
            $query->unionAll($unionQuery);
    
            $data = $query->orderBy('DocDate')->orderBy('DocNum')->get();
    

            $opening = DB::table('branches as b')
                    ->selectRaw("OpeningBalance")
                    ->where('b.BranchCode', session('branch_code'))->first();
            // Calculate totals for debit and credit
            $totalDebit = $data->sum('Debit');
            $totalCredit = $data->sum('Credit');
    
            return Datatables::of($data)
                ->addIndexColumn() // Add SlNo as an index column
                ->with('total_debit', $totalDebit) // Adding a new column for total debit
                ->with('total_credit', $totalCredit) // Adding a new column for total credit
                ->with('opening_value', $opening->OpeningBalance) // Adding a new column for total credit
                ->rawColumns([]) // If the value contains HTML, use rawColumns
                ->make(true);
        }
    
        return view('admin.cashbook');
    }
    





}
?>